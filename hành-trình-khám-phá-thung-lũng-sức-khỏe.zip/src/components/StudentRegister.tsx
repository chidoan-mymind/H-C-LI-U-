import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Compass, Sparkles, Trophy, Award, BookOpenCheck } from 'lucide-react';
import { soundFx } from '../utils/audio';

interface StudentRegisterProps {
  onStart: (name: string, className: string, avatarSeed: string) => void;
}

const AVATAR_OPTIONS = ['🍎', '🥦', '🥩', '🧀', '🍓', '🥑', '🦁', '🚀', '⭐'];

export const StudentRegister: React.FC<StudentRegisterProps> = ({ onStart }) => {
  const [name, setName] = useState('');
  const [className, setClassName] = useState('4A');
  const [selectedAvatar, setSelectedAvatar] = useState('🍎');
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      setError('Em hãy nhập họ và tên của mình nhé!');
      soundFx.playWrong();
      return;
    }
    soundFx.playFanfare();
    onStart(name.trim(), className.trim() || 'Lớp 4', selectedAvatar);
  };

  return (
    <div className="max-w-2xl mx-auto my-4 p-4 sm:p-6">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="bg-white rounded-3xl p-6 sm:p-8 shadow-xl border-4 border-emerald-300 relative overflow-hidden"
      >
        {/* Top Decorative Banner */}
        <div className="absolute top-0 inset-x-0 h-3 bg-gradient-to-r from-emerald-400 via-teal-400 to-amber-400" />

        <div className="text-center mb-8">
          <motion.div
            animate={{ rotate: [0, 5, -5, 0], scale: [1, 1.05, 1] }}
            transition={{ duration: 4, repeat: Infinity }}
            className="inline-flex items-center justify-center w-20 h-20 bg-[#88AA5B] rounded-full shadow-lg mb-4 text-white p-3 border-4 border-[#D8E4C0]"
          >
            <Compass className="w-10 h-10" />
          </motion.div>

          <span className="block text-xs font-bold uppercase tracking-widest text-[#5A6F4A] bg-[#E8F1D4] px-3.5 py-1 rounded-full w-fit mx-auto mb-3 border border-[#D8E4C0]">
            Học tập trải nghiệm Dinh Dưỡng Lớp 4
          </span>

          <h1 className="text-2xl sm:text-4xl font-serif font-bold text-[#1A2E1A] tracking-tight leading-tight uppercase">
            Hành Trình Khám Phá <br />
            <span className="text-[#88AA5B]">
              Thung Lũng Sức Khỏe
            </span>
          </h1>

          <p className="mt-3 text-[#4A5D3F] text-sm sm:text-base leading-relaxed max-w-lg mx-auto">
            Chào mừng nhà khám phá nhỏ! Thần Dinh Dưỡng đang rất chờ đợi được cùng em vượt qua 3 Vòng Thử Thách để mở khóa bí mật của sức khỏe!
          </p>
        </div>

        {/* 3 Rounds Overview Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mb-8">
          <div className="bg-[#F7FAF0] border-2 border-[#D8E4C0] p-3.5 rounded-2xl flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-[#88AA5B] text-white flex items-center justify-center shrink-0 font-bold text-sm shadow-xs">
              V1
            </div>
            <div>
              <p className="font-bold text-xs text-[#1A2E1A] uppercase">Đền Thờ Tri Thức</p>
              <p className="text-[11px] text-[#5A6F4A]">4 câu trắc nghiệm</p>
            </div>
          </div>

          <div className="bg-[#F7FAF0] border-2 border-[#D8E4C0] p-3.5 rounded-2xl flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-[#88AA5B] text-white flex items-center justify-center shrink-0 font-bold text-sm shadow-xs">
              V2
            </div>
            <div>
              <p className="font-bold text-xs text-[#1A2E1A] uppercase">Khu Rừng Phân Loại</p>
              <p className="text-[11px] text-[#5A6F4A]">Xếp món vào 4 giỏ</p>
            </div>
          </div>

          <div className="bg-[#F7FAF0] border-2 border-[#D8E4C0] p-3.5 rounded-2xl flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-[#88AA5B] text-white flex items-center justify-center shrink-0 font-bold text-sm shadow-xs">
              V3
            </div>
            <div>
              <p className="font-bold text-xs text-[#1A2E1A] uppercase">Giải Cứu Bạn Bi</p>
              <p className="text-[11px] text-[#5A6F4A]">Lời khuyên ăn uống</p>
            </div>
          </div>
        </div>

        {/* Registration Form */}
        <form onSubmit={handleSubmit} className="space-y-5 bg-[#E8F1D4]/40 p-6 rounded-3xl border-2 border-[#D8E4C0]">
          <div>
            <label className="block text-xs font-bold text-[#5A6F4A] uppercase tracking-wider mb-2">
              Họ và tên học sinh <span className="text-rose-500">*</span>
            </label>
            <input
              type="text"
              value={name}
              onChange={(e) => {
                setName(e.target.value);
                if (error) setError('');
              }}
              placeholder="Nhập tên của em (Ví dụ: Nguyễn Văn An)..."
              className="w-full px-4 py-3.5 rounded-2xl border-2 border-[#D8E4C0] focus:border-[#88AA5B] focus:bg-[#F7FAF0] outline-none transition-all text-[#1A2E1A] text-sm sm:text-base bg-white font-medium"
            />
            {error && <p className="mt-1.5 text-xs text-rose-600 font-bold flex items-center gap-1">⚠️ {error}</p>}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-[#5A6F4A] uppercase tracking-wider mb-2">
                Lớp học của em
              </label>
              <select
                value={className}
                onChange={(e) => setClassName(e.target.value)}
                className="w-full px-4 py-3.5 rounded-2xl border-2 border-[#D8E4C0] focus:border-[#88AA5B] focus:bg-[#F7FAF0] outline-none transition-all text-[#1A2E1A] text-sm bg-white font-medium"
              >
                <option value="4A">Lớp 4A</option>
                <option value="4B">Lớp 4B</option>
                <option value="4C">Lớp 4C</option>
                <option value="4D">Lớp 4D</option>
                <option value="Khối 4">Khối Lớp 4</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-[#5A6F4A] uppercase tracking-wider mb-2">
                Chọn biểu tượng may mắn
              </label>
              <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
                {AVATAR_OPTIONS.map((emoji) => (
                  <button
                    key={emoji}
                    type="button"
                    onClick={() => {
                      setSelectedAvatar(emoji);
                      soundFx.playClick();
                    }}
                    className={`w-10 h-10 rounded-xl text-xl flex items-center justify-center shrink-0 border-2 transition-all cursor-pointer ${
                      selectedAvatar === emoji
                        ? 'border-[#88AA5B] bg-[#E8F1D4] scale-110 shadow-xs'
                        : 'border-[#D8E4C0] bg-white hover:bg-[#F7FAF0]'
                    }`}
                  >
                    {emoji}
                  </button>
                ))}
              </div>
            </div>
          </div>

          <button
            type="submit"
            className="w-full py-4 px-8 rounded-full bg-[#F27D26] text-white font-bold text-lg sm:text-xl shadow-lg hover:brightness-110 active:scale-95 transition-all flex items-center justify-center gap-3 cursor-pointer mt-4 uppercase tracking-wide"
          >
            <span>BẮT ĐẦU KHÁM PHÁ</span>
            <Sparkles className="w-6 h-6 text-yellow-200 animate-bounce" />
          </button>
        </form>
      </motion.div>
    </div>
  );
};
