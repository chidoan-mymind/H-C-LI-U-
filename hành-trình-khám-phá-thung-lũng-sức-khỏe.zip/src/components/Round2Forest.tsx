import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { BASKETS, FOOD_ITEMS } from '../data/gameData';
import { FoodCategory, FoodItem } from '../types';
import { NutritionDeityAvatar } from './NutritionDeityAvatar';
import { CheckCircle, AlertCircle, RotateCcw, ArrowRight, Award, Sparkles, Filter } from 'lucide-react';
import { soundFx } from '../utils/audio';

interface Round2ForestProps {
  onComplete: (score: number) => void;
  audioEnabled: boolean;
  onToggleAudio: () => void;
  onOpenChat: () => void;
}

export const Round2Forest: React.FC<Round2ForestProps> = ({
  onComplete,
  audioEnabled,
  onToggleAudio,
  onOpenChat,
}) => {
  // Mapping of foodItemId -> assigned category (or null if unassigned)
  const [assignments, setAssignments] = useState<Record<string, FoodCategory | null>>(() => {
    const initial: Record<string, FoodCategory | null> = {};
    FOOD_ITEMS.forEach((item) => {
      initial[item.id] = null;
    });
    return initial;
  });

  const [selectedFoodId, setSelectedFoodId] = useState<string | null>(null);
  const [checkedResults, setCheckedResults] = useState<boolean>(false);
  const [feedbackMsg, setFeedbackMsg] = useState<string>('Em hãy xếp từng món ăn vào 1 trong 4 giỏ dinh dưỡng bên dưới nhé!');
  const [isRoundFinished, setIsRoundFinished] = useState<boolean>(false);
  const [calculatedScore, setCalculatedScore] = useState<number>(0);

  const selectedFood = FOOD_ITEMS.find((f) => f.id === selectedFoodId);

  // Unassigned items
  const unassignedFoods = FOOD_ITEMS.filter((f) => assignments[f.id] === null);

  const handleAssignFoodToCategory = (foodId: string, category: FoodCategory) => {
    soundFx.playClick();
    setAssignments((prev) => ({
      ...prev,
      [foodId]: category,
    }));
    setSelectedFoodId(null);
    setCheckedResults(false);
  };

  const handleRemoveFromBasket = (foodId: string) => {
    soundFx.playClick();
    setAssignments((prev) => ({
      ...prev,
      [foodId]: null,
    }));
    setCheckedResults(false);
  };

  const handleCheckAll = () => {
    if (unassignedFoods.length > 0) {
      soundFx.playWrong();
      setFeedbackMsg(`Vẫn còn ${unassignedFoods.length} món ăn chưa được xếp giỏ. Em hãy xếp hết các món ăn nhé! 🧺`);
      return;
    }

    let correctCount = 0;
    const errors: string[] = [];

    FOOD_ITEMS.forEach((item) => {
      const assigned = assignments[item.id];
      if (assigned === item.correctCategory) {
        correctCount += 1;
      } else {
        errors.push(item.name);
      }
    });

    const score = correctCount * 5; // 13 items * 5 = 65 max points
    setCalculatedScore(score);
    setCheckedResults(true);

    if (correctCount === FOOD_ITEMS.length) {
      soundFx.playFanfare();
      setIsRoundFinished(true);
      setFeedbackMsg(`Xuất sắc! Em đã xếp đúng toàn bộ 13/13 món ăn vào 4 nhóm chất dinh dưỡng! (+${score} điểm) 🎉`);
    } else {
      soundFx.playWrong();
      setFeedbackMsg(`Em đã xếp đúng ${correctCount}/${FOOD_ITEMS.length} món! Món bị nhầm: ${errors.join(', ')}. Em xem lại gợi ý ở từng giỏ và chỉnh lại nhé! 💪`);
    }
  };

  const handleReset = () => {
    soundFx.playClick();
    const resetObj: Record<string, FoodCategory | null> = {};
    FOOD_ITEMS.forEach((f) => {
      resetObj[f.id] = null;
    });
    setAssignments(resetObj);
    setSelectedFoodId(null);
    setCheckedResults(false);
    setFeedbackMsg('Đã làm mới! Em chọn từng món rồi chọn Giỏ tương ứng nhé!');
  };

  return (
    <div className="max-w-4xl mx-auto p-4 sm:p-6 space-y-6">
      {/* Deity Avatar */}
      <NutritionDeityAvatar
        message={feedbackMsg}
        mood={isRoundFinished ? 'celebrate' : checkedResults ? 'thinking' : 'happy'}
        audioEnabled={audioEnabled}
        onToggleAudio={onToggleAudio}
        onAskClick={onOpenChat}
      />

      {!isRoundFinished ? (
        <div className="space-y-6">
          {/* Top Food Shelf / Unassigned Inventory */}
          <div className="bg-white/90 backdrop-blur-sm rounded-[32px] p-5 sm:p-6 border-2 border-[#D8E4C0] shadow-sm">
            <div className="flex items-center justify-between mb-4 border-b border-[#D8E4C0] pb-3">
              <div className="flex items-center gap-2">
                <Filter className="w-5 h-5 text-[#88AA5B]" />
                <h3 className="font-serif font-bold text-base sm:text-lg text-[#1A2E1A]">
                  Món Ăn Cần Phân Loại ({unassignedFoods.length} món còn lại)
                </h3>
              </div>
              <span className="text-xs text-[#5A6F4A] font-bold uppercase tracking-wider">
                Chạm món ➔ Chọn giỏ để xếp
              </span>
            </div>

            {unassignedFoods.length === 0 ? (
              <div className="py-5 text-center bg-[#F7FAF0] rounded-2xl border-2 border-[#D8E4C0]">
                <p className="text-base font-bold text-[#88AA5B]">
                  🎉 Em đã xếp xong toàn bộ 13 món ăn! Hãy bấm "KIỂM TRA KẾT QUẢ" bên dưới nhé!
                </p>
              </div>
            ) : (
              <div className="flex flex-wrap gap-3">
                {unassignedFoods.map((food) => {
                  const isSelected = selectedFoodId === food.id;
                  return (
                    <motion.button
                      key={food.id}
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      onClick={() => {
                        soundFx.playClick();
                        setSelectedFoodId(isSelected ? null : food.id);
                      }}
                      className={`px-4 py-2.5 rounded-2xl border-2 font-bold text-sm sm:text-base flex items-center gap-2 transition-all cursor-pointer shadow-xs ${
                        isSelected
                          ? 'bg-[#F27D26] text-white border-[#F27D26] ring-4 ring-[#F27D26]/20 scale-105'
                          : 'bg-white hover:bg-[#F7FAF0] text-[#1A2E1A] border-[#D8E4C0]'
                      }`}
                    >
                      <span className="text-xl">{food.emoji}</span>
                      <span>{food.name}</span>
                    </motion.button>
                  );
                })}
              </div>
            )}
          </div>

          {/* 4 Baskets Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {BASKETS.map((basket) => {
              const itemsInBasket = FOOD_ITEMS.filter((f) => assignments[f.id] === basket.id);

              return (
                <div
                  key={basket.id}
                  onClick={() => {
                    if (selectedFoodId) {
                      handleAssignFoodToCategory(selectedFoodId, basket.id);
                    }
                  }}
                  className={`relative rounded-[28px] p-5 border-2 transition-all bg-white/95 shadow-xs ${
                    selectedFoodId ? 'border-[#F27D26] border-dashed hover:bg-[#F7FAF0] cursor-pointer ring-2 ring-[#F27D26]/30' : 'border-[#D8E4C0]'
                  }`}
                >
                  {/* Basket Header */}
                  <div className="flex items-start justify-between gap-2 border-b border-[#D8E4C0] pb-3 mb-3">
                    <div className="flex items-center gap-3">
                      <div className="w-11 h-11 rounded-2xl bg-[#88AA5B] text-white flex items-center justify-center text-2xl shadow-xs shrink-0 font-serif font-bold">
                        {basket.icon}
                      </div>
                      <div>
                        <h4 className="font-serif font-bold text-base text-[#1A2E1A] leading-tight">
                          {basket.title}
                        </h4>
                        <p className="text-xs text-[#5A6F4A] font-medium">{basket.subTitle}</p>
                      </div>
                    </div>

                    <span className="text-xs font-bold px-3 py-1 rounded-full bg-[#E8F1D4] text-[#5A6F4A] border border-[#D8E4C0]">
                      {itemsInBasket.length} món
                    </span>
                  </div>

                  <p className="text-xs text-[#5A6F4A]/80 italic mb-3">{basket.examples}</p>

                  {/* Items list inside this basket */}
                  <div className="min-h-[90px] p-3 bg-[#F7FAF0] rounded-2xl border border-[#D8E4C0] flex flex-wrap gap-2 items-center">
                    {itemsInBasket.length === 0 ? (
                      <p className="text-xs text-[#5A6F4A] italic mx-auto py-4 text-center font-medium">
                        {selectedFoodId ? '👉 Chạm vào đây để xếp món này' : 'Chưa có món nào trong giỏ'}
                      </p>
                    ) : (
                      itemsInBasket.map((food) => {
                        const isItemCorrect = food.correctCategory === basket.id;

                        return (
                          <motion.div
                            key={food.id}
                            initial={{ scale: 0.8, opacity: 0 }}
                            animate={{ scale: 1, opacity: 1 }}
                            className={`px-3.5 py-2 rounded-xl border-2 font-bold text-xs sm:text-sm flex items-center gap-2 shadow-xs ${
                              checkedResults
                                ? isItemCorrect
                                  ? 'bg-[#E8F1D4] text-[#1A2E1A] border-[#88AA5B]'
                                  : 'bg-rose-100 text-rose-950 border-rose-400 animate-pulse'
                                : 'bg-white text-[#1A2E1A] border-[#D8E4C0]'
                            }`}
                          >
                            <span className="text-base">{food.emoji}</span>
                            <span>{food.name}</span>
                            {checkedResults && (
                              <span>{isItemCorrect ? '✅' : '❌'}</span>
                            )}
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                handleRemoveFromBasket(food.id);
                              }}
                              className="text-slate-400 hover:text-rose-600 ml-1 font-bold cursor-pointer text-base"
                              title="Bỏ ra khỏi giỏ"
                            >
                              ×
                            </button>
                          </motion.div>
                        );
                      })
                    )}
                  </div>
                </div>
              );
            })}
          </div>

          {/* Action Footer */}
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4 bg-white/90 p-5 rounded-[28px] border-2 border-[#D8E4C0] shadow-sm">
            <button
              onClick={handleReset}
              className="w-full sm:w-auto px-6 py-3 rounded-full border-2 border-[#D8E4C0] hover:bg-[#E8F1D4] text-[#5A6F4A] font-bold text-sm flex items-center justify-center gap-2 cursor-pointer uppercase tracking-wide"
            >
              <RotateCcw className="w-4 h-4" />
              <span>LÀM MỚI</span>
            </button>

            <button
              onClick={handleCheckAll}
              className="w-full sm:w-auto px-10 py-4 rounded-full bg-[#F27D26] text-white font-bold text-base sm:text-lg shadow-lg hover:brightness-110 active:scale-95 transition-all flex items-center justify-center gap-3 cursor-pointer uppercase tracking-wide"
            >
              <span>KIỂM TRA KẾT QUẢ (13 MÓN)</span>
              <Sparkles className="w-5 h-5 text-yellow-200" />
            </button>
          </div>
        </div>
      ) : (
        /* Victory Card for Round 2 */
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="bg-white rounded-[32px] p-6 sm:p-10 border-4 border-[#88AA5B] shadow-2xl text-center relative overflow-hidden space-y-6"
        >
          <div className="w-20 h-20 bg-[#E8F1D4] text-[#88AA5B] rounded-3xl flex items-center justify-center mx-auto border-2 border-[#D8E4C0] shadow-md">
            <Award className="w-10 h-10" />
          </div>

          <div>
            <span className="text-xs font-bold uppercase tracking-widest text-[#5A6F4A] bg-[#E8F1D4] px-4 py-1.5 rounded-full border border-[#D8E4C0]">
              Hoàn thành Vòng 2
            </span>

            <h2 className="text-2xl sm:text-4xl font-serif font-bold text-[#1A2E1A] mt-3">
              Khu Rừng Phân Loại Đã Tươi Xanh!
            </h2>

            <p className="text-[#4A5D3F] mt-2 text-base max-w-md mx-auto leading-relaxed">
              Em đã xuất sắc phân loại chính xác 13 loại thực phẩm vào 4 giỏ dinh dưỡng chính!
            </p>
          </div>

          <div className="p-5 bg-[#F7FAF0] rounded-2xl border-2 border-[#D8E4C0] inline-block text-center min-w-[260px]">
            <p className="text-xs text-[#5A6F4A] font-bold uppercase tracking-wider">Điểm Vòng 2 của em</p>
            <p className="text-4xl font-bold text-[#88AA5B] mt-1">{calculatedScore} / 65 điểm</p>
            <div className="mt-2 text-xs font-bold text-emerald-900 bg-emerald-100 px-3 py-1 rounded-full inline-flex items-center gap-1 border border-emerald-300">
              🏆 Huy Hiệu: Bậc Thầy Phân Loại
            </div>
          </div>

          <div>
            <button
              onClick={() => onComplete(calculatedScore)}
              className="w-full sm:w-auto px-10 py-4 rounded-full bg-[#F27D26] text-white font-bold text-lg shadow-xl hover:brightness-110 active:scale-95 transition-all flex items-center justify-center gap-3 mx-auto cursor-pointer uppercase tracking-wide"
            >
              <span>VÒNG 3: GIẢI CỨU BẠN BI ➔</span>
            </button>
          </div>
        </motion.div>
      )}
    </div>
  );
};
