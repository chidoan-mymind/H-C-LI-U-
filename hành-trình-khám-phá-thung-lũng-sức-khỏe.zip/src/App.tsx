import React, { useState } from 'react';
import { RoundScore, RoundType, StudentProfile } from './types';
import { StudentRegister } from './components/StudentRegister';
import { GameHeader } from './components/GameHeader';
import { Round1Temple } from './components/Round1Temple';
import { Round2Forest } from './components/Round2Forest';
import { Round3RescueBi } from './components/Round3RescueBi';
import { Certificate } from './components/Certificate';
import { DeityChatModal } from './components/DeityChatModal';
import { ConfettiCanvas } from './components/ConfettiCanvas';
import { soundFx } from './utils/audio';

export default function App() {
  const [currentRound, setCurrentRound] = useState<RoundType>('welcome');
  const [student, setStudent] = useState<StudentProfile>({
    name: '',
    className: '4A',
    avatarSeed: '🍎',
  });

  const [scores, setScores] = useState<RoundScore>({
    round1: 0,
    round2: 0,
    round3: 0,
  });

  const [audioEnabled, setAudioEnabled] = useState<boolean>(true);
  const [isChatOpen, setIsChatOpen] = useState<boolean>(false);
  const [confettiActive, setConfettiActive] = useState<boolean>(false);

  const triggerCelebration = () => {
    setConfettiActive(true);
    setTimeout(() => {
      setConfettiActive(false);
    }, 3500);
  };

  const handleStartGame = (name: string, className: string, avatarSeed: string) => {
    setStudent({ name, className, avatarSeed });
    setCurrentRound('round1');
    soundFx.speak(`Thần Dinh Dưỡng xin chào ${name}! Hãy bắt đầu Vòng 1 Đền Thờ Tri Thức nào!`);
  };

  const handleCompleteRound1 = (score: number) => {
    setScores((prev) => ({ ...prev, round1: score }));
    triggerCelebration();
    setCurrentRound('round2');
    soundFx.speak(`Chúc mừng ${student.name}! Tiếp theo là Vòng 2 Khu Rừng Phân Loại thực phẩm!`);
  };

  const handleCompleteRound2 = (score: number) => {
    setScores((prev) => ({ ...prev, round2: score }));
    triggerCelebration();
    setCurrentRound('round3');
    soundFx.speak(`Tuyệt vời! Bây giờ hãy cùng Thần Dinh Dưỡng Giải Cứu Bạn Bi ở Vòng 3 nhé!`);
  };

  const handleCompleteRound3 = (score: number) => {
    setScores((prev) => ({ ...prev, round3: score }));
    triggerCelebration();
    setCurrentRound('certificate');
    soundFx.speak(`Xuất sắc! Em đã chính thức trở thành Anh Hùng Dinh Dưỡng! Đây là bằng khen của em!`);
  };

  const handleRestart = () => {
    setScores({ round1: 0, round2: 0, round3: 0 });
    setCurrentRound('welcome');
    soundFx.stopSpeech();
  };

  const totalScore = scores.round1 + scores.round2 + scores.round3;

  return (
    <div className="min-h-screen bg-[#FDFCF0] text-[#2D402A] font-sans selection:bg-[#E8F1D4] selection:text-[#1A2E1A] pb-12 relative overflow-hidden">
      {/* Decorative Organic Natural Forest Elements */}
      <div className="absolute top-0 right-0 w-96 h-96 bg-[#E8F1D4] rounded-full blur-3xl -z-10 opacity-60 pointer-events-none" />
      <div className="absolute bottom-0 left-0 w-80 h-80 bg-[#D8E4C0] rounded-full blur-3xl -z-10 opacity-50 pointer-events-none" />

      {/* Confetti Celebration overlay */}
      <ConfettiCanvas active={confettiActive} durationMs={3500} />

      {/* Main Game Header (visible after registration) */}
      {currentRound !== 'welcome' && (
        <GameHeader
          currentRound={currentRound}
          student={student}
          totalScore={totalScore}
          audioEnabled={audioEnabled}
          onToggleAudio={() => {
            const next = !audioEnabled;
            setAudioEnabled(next);
            soundFx.setTTS(next);
          }}
          onOpenChat={() => setIsChatOpen(true)}
          onRestart={handleRestart}
        />
      )}

      {/* Dynamic Screen Router */}
      <main className="container mx-auto px-2 sm:px-4 py-4">
        {currentRound === 'welcome' && (
          <StudentRegister onStart={handleStartGame} />
        )}

        {currentRound === 'round1' && (
          <Round1Temple
            onComplete={handleCompleteRound1}
            audioEnabled={audioEnabled}
            onToggleAudio={() => {
              const next = !audioEnabled;
              setAudioEnabled(next);
              soundFx.setTTS(next);
            }}
            onOpenChat={() => setIsChatOpen(true)}
          />
        )}

        {currentRound === 'round2' && (
          <Round2Forest
            onComplete={handleCompleteRound2}
            audioEnabled={audioEnabled}
            onToggleAudio={() => {
              const next = !audioEnabled;
              setAudioEnabled(next);
              soundFx.setTTS(next);
            }}
            onOpenChat={() => setIsChatOpen(true)}
          />
        )}

        {currentRound === 'round3' && (
          <Round3RescueBi
            student={student}
            onComplete={handleCompleteRound3}
            audioEnabled={audioEnabled}
            onToggleAudio={() => {
              const next = !audioEnabled;
              setAudioEnabled(next);
              soundFx.setTTS(next);
            }}
            onOpenChat={() => setIsChatOpen(true)}
          />
        )}

        {currentRound === 'certificate' && (
          <Certificate
            student={student}
            scores={scores}
            onRestart={handleRestart}
          />
        )}
      </main>

      {/* Deity AI Q&A Modal */}
      <DeityChatModal
        isOpen={isChatOpen}
        onClose={() => setIsChatOpen(false)}
        student={student}
      />
    </div>
  );
}
