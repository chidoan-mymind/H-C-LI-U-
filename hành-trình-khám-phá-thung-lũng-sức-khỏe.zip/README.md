# Hành Trình Khám Phá Thung Lũng Sức Khỏe - Dinh Dưỡng Lớp 4

Ứng dụng web học tập trải nghiệm tương tác dành cho học sinh Lớp 4, thuộc môn Tự nhiên và Xã hội (Chủ đề Dinh Dưỡng & Sức Khỏe).

## 🌟 Tính năng chính

1. **Đăng ký học sinh**: Nhập tên, lớp và chọn avatar biểu tượng may mắn.
2. **Vòng 1 - Đền Thờ Tri Thức**: Trắc nghiệm tương tác kiểm tra kiến thức về 4 nhóm chất dinh dưỡng.
3. **Vòng 2 - Khu Rừng Phân Loại**: Kéo/chạm để sắp xếp 13 loại thực phẩm vào 4 giỏ dinh dưỡng chính.
4. **Vòng 3 - Giải Cứu Bạn Bi**: Phân tích tình huống ăn uống lệch lạc của bạn Bi và viết lời khuyên cân bằng (tích hợp AI đánh giá chân thực).
5. **Bằng Báo Công & Bằng Khen**: Tổng kết điểm số, xếp hạng danh hiệu và hỗ trợ In / Tải chứng nhận PDF/Print.

## 🛠️ Công nghệ sử dụng

- **Frontend**: React 18, TypeScript, Vite, Tailwind CSS, Motion (Framer Motion), Lucide React, Canvas Confetti.
- **Backend**: Node.js, Express.
- **AI Integration**: Google Gemini API (`@google/genai`) hỗ trợ đánh giá lời khuyên của học sinh ở Vòng 3.

## 🚀 Hướng dẫn chạy dự án ở máy cục bộ (Local)

### 1. Cài đặt phụ thuộc
```bash
npm install
```

### 2. Cấu hình biến môi trường
Tạo file `.env` dựa trên `.env.example`:
```env
GEMINI_API_KEY=your_gemini_api_key_here
```

### 3. Chạy môi trường Phát triển (Development)
```bash
npm run dev
```
Ứng dụng sẽ chạy tại địa chỉ: `http://localhost:3000`

### 4. Đóng gói cho Sản xuất (Production)
```bash
npm run build
npm start
```
