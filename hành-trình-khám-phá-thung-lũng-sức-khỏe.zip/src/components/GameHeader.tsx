import React from 'react';
import { RoundType, StudentProfile } from '../types';
import { Trophy, Star, Volume2, VolumeX, MessageSquare, RotateCcw } from 'lucide-react';
import { soundFx } from '../utils/audio';

interface GameHeaderProps {
  currentRound: RoundType;
  student: StudentProfile;
  totalScore: number;
  audioEnabled: boolean;
  onToggleAudio: () => void;
  onOpenChat: () => void;
  onRestart: () => void;
}

export const GameHeader: React.FC<GameHeaderProps> = ({
  currentRound,
  student,
  totalScore,
  audioEnabled,
  onToggleAudio,
  onOpenChat,
  onRestart,
}) => {
  const getRoundProgress = () => {
    switch (currentRound) {
      case 'round1':
        return 33;
      case 'round2':
        return 66;
      case 'round3':
        return 90;
      case 'certificate':
        return 100;
      default:
        return 0;
    }
  };

  return (
    <header className="sticky top-0 z-40 bg-[#88AA5B] text-white shadow-md border-b-2 border-[#5A6F4A]/30 px-3 sm:px-6 py-3">
      <div className="max-w-5xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-2 sm:gap-4">
        {/* Left: Student Profile & Title */}
        <div className="flex items-center gap-3 w-full sm:w-auto justify-between sm:justify-start">
          <div className="flex items-center gap-2.5">
            <div className="w-11 h-11 rounded-full bg-white text-[#88AA5B] flex items-center justify-center text-2xl shadow-inner shrink-0 border-2 border-[#D8E4C0]">
              {student.avatarSeed || '🍎'}
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <p className="font-bold text-sm text-white leading-tight uppercase tracking-wide">
                  {student.name}
                </p>
                <span className="text-[10px] font-extrabold bg-white/20 text-white px-2 py-0.5 rounded-full border border-white/30">
                  Lớp {student.className}
                </span>
              </div>
              <p className="text-[11px] text-white/90 font-medium">Hành Trình Khám Phá Thung Lũng Sức Khỏe</p>
            </div>
          </div>

          {/* Mobile Score Badge */}
          <div className="sm:hidden flex items-center gap-1 bg-[#F27D26] text-white font-bold text-xs px-3 py-1 rounded-full shadow-xs">
            <Star className="w-3.5 h-3.5 fill-white text-white" />
            <span>{totalScore} Điểm 🏆</span>
          </div>
        </div>

        {/* Center: Round Progress Indicators */}
        <div className="flex items-center gap-1.5 sm:gap-2 w-full sm:w-auto justify-center">
          <div className={`px-3 py-1 rounded-full text-xs font-bold uppercase transition-all flex items-center gap-1 ${
            currentRound === 'round1'
              ? 'bg-white text-[#5A6F4A] shadow-xs scale-105'
              : 'bg-black/15 text-white/80'
          }`}>
            <span>V1: Đền Thờ</span>
          </div>

          <span className="text-white/60 text-xs">➔</span>

          <div className={`px-3 py-1 rounded-full text-xs font-bold uppercase transition-all flex items-center gap-1 ${
            currentRound === 'round2'
              ? 'bg-white text-[#5A6F4A] shadow-xs scale-105'
              : 'bg-black/15 text-white/80'
          }`}>
            <span>V2: Khu Rừng</span>
          </div>

          <span className="text-white/60 text-xs">➔</span>

          <div className={`px-3 py-1 rounded-full text-xs font-bold uppercase transition-all flex items-center gap-1 ${
            currentRound === 'round3'
              ? 'bg-white text-[#5A6F4A] shadow-xs scale-105'
              : 'bg-black/15 text-white/80'
          }`}>
            <span>V3: Bạn Bi</span>
          </div>
        </div>

        {/* Right: Actions & Desktop Score */}
        <div className="flex items-center gap-2">
          {/* Score Badge */}
          <div className="hidden sm:flex items-center gap-1.5 bg-[#F27D26] text-white font-bold text-sm px-3.5 py-1.5 rounded-full shadow-sm">
            <Trophy className="w-4 h-4 text-white" />
            <span>{totalScore} Điểm 🏆</span>
          </div>

          {/* Ask Deity button */}
          <button
            onClick={() => {
              soundFx.playClick();
              onOpenChat();
            }}
            className="p-2 rounded-xl bg-white/20 hover:bg-white/30 text-white transition-colors cursor-pointer"
            title="Hỏi Thần Dinh Dưỡng"
          >
            <MessageSquare className="w-4 h-4" />
          </button>

          {/* Audio toggle */}
          <button
            onClick={() => {
              onToggleAudio();
              soundFx.playClick();
            }}
            className="p-2 rounded-xl bg-white/20 hover:bg-white/30 text-white transition-colors cursor-pointer"
            title={audioEnabled ? 'Tắt âm thanh/giọng nói' : 'Bật âm thanh/giọng nói'}
          >
            {audioEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4 text-white/60" />}
          </button>

          {/* Restart button */}
          <button
            onClick={() => {
              if (window.confirm('Em có muốn chơi lại từ đầu không?')) {
                soundFx.playClick();
                onRestart();
              }
            }}
            className="p-2 rounded-xl bg-white/20 hover:bg-white/30 text-white transition-colors cursor-pointer"
            title="Chơi lại từ đầu"
          >
            <RotateCcw className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Progress Line */}
      <div className="w-full bg-black/10 h-2 rounded-full mt-2.5 overflow-hidden max-w-5xl mx-auto">
        <div
          className="bg-[#FFD700] h-full transition-all duration-500 rounded-full"
          style={{ width: `${getRoundProgress()}%` }}
        />
      </div>
    </header>
  );
};
