import React from 'react';
import { motion } from 'motion/react';
import { Volume2, VolumeX, Sparkles, MessageSquareHeart } from 'lucide-react';
import { soundFx } from '../utils/audio';

interface DeityAvatarProps {
  message: string;
  mood?: 'happy' | 'thinking' | 'proud' | 'celebrate' | 'encouraging';
  onAskClick?: () => void;
  audioEnabled: boolean;
  onToggleAudio: () => void;
  compact?: boolean;
}

export const NutritionDeityAvatar: React.FC<DeityAvatarProps> = ({
  message,
  mood = 'happy',
  onAskClick,
  audioEnabled,
  onToggleAudio,
  compact = false,
}) => {
  const handleSpeak = () => {
    soundFx.speak(message);
  };

  // Expression SVGs based on mood
  const renderMouth = () => {
    switch (mood) {
      case 'celebrate':
      case 'proud':
        return <path d="M 38 62 Q 50 78 62 62 Z" fill="#e11d48" />;
      case 'thinking':
        return <path d="M 40 64 Q 50 60 60 64" stroke="#e11d48" strokeWidth="3" fill="none" strokeLinecap="round" />;
      case 'encouraging':
        return <path d="M 38 60 Q 50 72 62 60" stroke="#e11d48" strokeWidth="4" fill="none" strokeLinecap="round" />;
      default:
        return <path d="M 38 60 Q 50 74 62 60" stroke="#e11d48" strokeWidth="4" fill="none" strokeLinecap="round" />;
    }
  };

  return (
    <div className={`relative flex ${compact ? 'flex-row items-center gap-3' : 'flex-col sm:flex-row items-start sm:items-center gap-5'} bg-white/90 rounded-[32px] sm:rounded-[40px] p-5 sm:p-6 shadow-lg border-4 border-[#88AA5B] relative backdrop-blur-sm`}>
      {/* Thần Dinh Dưỡng Animated Avatar */}
      <div className="relative shrink-0 flex flex-col items-center">
        <motion.div
          animate={{
            y: mood === 'celebrate' ? [0, -8, 0] : [0, -4, 0],
            rotate: mood === 'celebrate' ? [0, 3, -3, 0] : 0,
          }}
          transition={{
            duration: mood === 'celebrate' ? 0.8 : 3,
            repeat: Infinity,
            ease: 'easeInOut',
          }}
          className="relative w-20 h-20 sm:w-24 sm:h-24 drop-shadow-md"
        >
          {/* Glowing Aura */}
          <div className="absolute inset-0 bg-gradient-to-tr from-[#E8F1D4] via-[#D8E4C0] to-[#88AA5B] rounded-full blur-md opacity-70 animate-pulse" />

          {/* Deity Body & Head SVG */}
          <svg viewBox="0 0 100 100" className="w-full h-full relative z-10">
            {/* Halo of Nutrients */}
            <circle cx="50" cy="50" r="46" fill="none" stroke="#88AA5B" strokeWidth="2.5" strokeDasharray="6 4" />
            <text x="50" y="8" fontSize="9" textAnchor="middle">✨</text>
            <text x="92" y="52" fontSize="9" textAnchor="middle">🍎</text>
            <text x="50" y="98" fontSize="9" textAnchor="middle">🥦</text>
            <text x="8" y="52" fontSize="9" textAnchor="middle">🥑</text>

            {/* Cloud/Deity Cloak */}
            <path d="M 20 85 C 20 65, 80 65, 80 85 C 80 95, 20 95, 20 85 Z" fill="#88AA5B" />
            <path d="M 32 68 Q 50 60 68 68 L 68 85 Q 50 92 32 85 Z" fill="#5A6F4A" />

            {/* Head */}
            <circle cx="50" cy="48" r="26" fill="#fde047" />
            <circle cx="50" cy="48" r="24" fill="#fef08a" />

            {/* Golden Crown */}
            <path d="M 32 30 L 38 18 L 50 26 L 62 18 L 68 30 Z" fill="#f59e0b" stroke="#d97706" strokeWidth="1" />
            <circle cx="50" cy="22" r="3" fill="#ef4444" />
            <circle cx="38" cy="23" r="2" fill="#3b82f6" />
            <circle cx="62" cy="23" r="2" fill="#10b981" />

            {/* Eyes */}
            {mood === 'celebrate' ? (
              <>
                <path d="M 38 42 Q 42 36 46 42" stroke="#1A2E1A" strokeWidth="3.5" fill="none" strokeLinecap="round" />
                <path d="M 54 42 Q 58 36 62 42" stroke="#1A2E1A" strokeWidth="3.5" fill="none" strokeLinecap="round" />
              </>
            ) : mood === 'thinking' ? (
              <>
                <circle cx="42" cy="42" r="3.5" fill="#1A2E1A" />
                <path d="M 54 40 Q 58 44 62 40" stroke="#1A2E1A" strokeWidth="3" fill="none" strokeLinecap="round" />
              </>
            ) : (
              <>
                <circle cx="42" cy="44" r="3.5" fill="#1A2E1A" />
                <circle cx="58" cy="44" r="3.5" fill="#1A2E1A" />
                <circle cx="43.5" cy="42.5" r="1.2" fill="#ffffff" />
                <circle cx="59.5" cy="42.5" r="1.2" fill="#ffffff" />
              </>
            )}

            {/* Cheeks */}
            <circle cx="35" cy="52" r="4" fill="#f43f5e" opacity="0.4" />
            <circle cx="65" cy="52" r="4" fill="#f43f5e" opacity="0.4" />

            {/* Mouth */}
            {renderMouth()}
          </svg>

          {/* Sparkles */}
          <motion.div
            animate={{ scale: [1, 1.2, 1], rotate: [0, 180, 360] }}
            transition={{ duration: 2, repeat: Infinity }}
            className="absolute -top-1 -right-1 text-amber-500"
          >
            <Sparkles className="w-5 h-5 fill-amber-300" />
          </motion.div>
        </motion.div>

        <span className="font-bold text-xs uppercase tracking-tighter italic font-serif text-[#5A6F4A] bg-[#E8F1D4] px-3 py-1 rounded-full border border-[#88AA5B]/40 shadow-xs mt-1.5 whitespace-nowrap">
          Thần Dinh Dưỡng
        </span>
      </div>

      {/* Speech Bubble */}
      <div className="flex-1 min-w-0 w-full">
        <div className="relative bg-[#F7FAF0] border-2 border-[#D8E4C0] rounded-2xl p-4 sm:p-5 shadow-xs text-[#2D402A]">
          {/* Speech bubble pointer */}
          <div className="hidden sm:block absolute -left-2.5 top-6 w-4 h-4 bg-[#F7FAF0] border-b-2 border-l-2 border-[#D8E4C0] rotate-45" />

          <p className="text-base sm:text-lg leading-relaxed text-[#4A5D3F] font-medium font-sans">
            "{message}"
          </p>

          <div className="mt-3 flex flex-wrap items-center justify-between gap-2 border-t border-[#D8E4C0] pt-2.5">
            {/* Audio Voice button */}
            <button
              onClick={() => {
                onToggleAudio();
                handleSpeak();
              }}
              className="inline-flex items-center gap-1.5 text-xs font-bold px-3 py-1.5 rounded-xl bg-white text-[#5A6F4A] hover:bg-[#E8F1D4] transition-colors border border-[#D8E4C0] cursor-pointer"
              title="Đọc lời nhắn của Thần Dinh Dưỡng"
            >
              {audioEnabled ? <Volume2 className="w-3.5 h-3.5 text-[#88AA5B] animate-pulse" /> : <VolumeX className="w-3.5 h-3.5 text-slate-400" />}
              <span>{audioEnabled ? 'Nghe Thần Dinh Dưỡng nói' : 'Bật Giọng Nói'}</span>
            </button>

            {/* Ask Deity AI Chat Modal Trigger */}
            {onAskClick && (
              <button
                onClick={onAskClick}
                className="inline-flex items-center gap-1.5 text-xs font-bold px-3.5 py-1.5 rounded-full bg-[#F27D26] text-white hover:brightness-110 transition-all shadow-xs cursor-pointer active:scale-95 uppercase tracking-wide"
              >
                <MessageSquareHeart className="w-3.5 h-3.5" />
                <span>Hỏi Thần Dinh Dưỡng 💡</span>
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
