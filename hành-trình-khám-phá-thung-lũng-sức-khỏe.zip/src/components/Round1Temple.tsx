import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ROUND1_QUESTIONS } from '../data/gameData';
import { NutritionDeityAvatar } from './NutritionDeityAvatar';
import { CheckCircle2, HelpCircle, ArrowRight, Sparkles, Check, X, Award } from 'lucide-react';
import { soundFx } from '../utils/audio';

interface Round1TempleProps {
  onComplete: (score: number) => void;
  audioEnabled: boolean;
  onToggleAudio: () => void;
  onOpenChat: () => void;
}

export const Round1Temple: React.FC<Round1TempleProps> = ({
  onComplete,
  audioEnabled,
  onToggleAudio,
  onOpenChat,
}) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [selectedKey, setSelectedKey] = useState<'A' | 'B' | 'C' | null>(null);
  const [isAnswered, setIsAnswered] = useState(false);
  const [isCorrect, setIsCorrect] = useState(false);
  const [roundScore, setRoundScore] = useState(0);
  const [isRoundFinished, setIsRoundFinished] = useState(false);

  const currentQ = ROUND1_QUESTIONS[currentIndex];

  const handleSelectOption = (key: 'A' | 'B' | 'C') => {
    if (isAnswered) return;
    setSelectedKey(key);
    setIsAnswered(true);

    const correct = key === currentQ.correctKey;
    setIsCorrect(correct);

    if (correct) {
      soundFx.playCorrect();
      setRoundScore((prev) => prev + 10);
    } else {
      soundFx.playWrong();
    }
  };

  const handleNext = () => {
    soundFx.playClick();
    setSelectedKey(null);
    setIsAnswered(false);
    setIsCorrect(false);

    if (currentIndex < ROUND1_QUESTIONS.length - 1) {
      setCurrentIndex((prev) => prev + 1);
    } else {
      setIsRoundFinished(true);
      soundFx.playFanfare();
    }
  };

  const handleRetryCurrent = () => {
    soundFx.playClick();
    setSelectedKey(null);
    setIsAnswered(false);
    setIsCorrect(false);
  };

  // Deity message based on state
  const getDeityMessage = () => {
    if (isRoundFinished) {
      return `Hoan hô! Em đã xuất sắc hoàn thành Vòng 1: Đền Thờ Tri Thức với ${roundScore}/40 điểm! Hãy tiến vào Khu Rừng Phân Loại nào! 🌲`;
    }
    if (!isAnswered) {
      return `Câu hỏi ${currentIndex + 1}/4: Em hãy suy nghĩ kĩ và chọn phương án đúng nhất nhé! Thần tin em làm được! ⭐`;
    }
    if (isCorrect) {
      return `Tuyệt vời lắm! ${currentQ.explanation}`;
    } else {
      return `Chưa chính xác mất rồi! Không sao cả, em hãy xem gợi ý và thử lại nhé: Đọc kĩ từng đáp án xem đáp án nào đầy đủ nhất! 🌱`;
    }
  };

  return (
    <div className="max-w-3xl mx-auto p-4 sm:p-6 space-y-6">
      {/* Thần Dinh Dưỡng Companion Header */}
      <NutritionDeityAvatar
        message={getDeityMessage()}
        mood={isRoundFinished ? 'celebrate' : isCorrect ? 'proud' : isAnswered ? 'thinking' : 'happy'}
        audioEnabled={audioEnabled}
        onToggleAudio={onToggleAudio}
        onAskClick={onOpenChat}
      />

      {!isRoundFinished ? (
        <AnimatePresence mode="wait">
          <motion.div
            key={currentIndex}
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            transition={{ duration: 0.3 }}
            className="bg-white/90 backdrop-blur-sm rounded-[32px] p-6 sm:p-8 border-2 border-[#D8E4C0] shadow-sm relative overflow-hidden"
          >
            {/* Header Badge */}
            <div className="flex items-center justify-between gap-2 mb-6 border-b border-[#D8E4C0] pb-4">
              <span className="text-xs font-bold uppercase tracking-widest text-[#88AA5B] flex items-center gap-1.5">
                <HelpCircle className="w-4 h-4 text-[#88AA5B]" />
                Vòng 1: Đền Thờ Tri Thức
              </span>
              <span className="bg-[#5A6F4A] text-white px-3.5 py-1 rounded-lg text-xs font-bold">
                Câu {currentIndex + 1} / {ROUND1_QUESTIONS.length}
              </span>
            </div>

            {/* Question Text */}
            <h2 className="text-2xl sm:text-3xl font-serif font-bold text-[#1A2E1A] leading-tight mb-8">
              {currentQ.text}
            </h2>

            {/* Answer Options */}
            <div className="flex flex-col gap-4">
              {currentQ.options.map((opt) => {
                const isSelected = selectedKey === opt.key;
                const isTargetCorrect = opt.key === currentQ.correctKey;

                let optionWrapperStyle = 'bg-white border-2 border-[#D8E4C0] hover:border-[#88AA5B] hover:bg-[#F7FAF0] text-[#2D402A]';
                let badgeStyle = 'bg-[#D8E4C0] text-[#5A6F4A] group-hover:bg-[#88AA5B] group-hover:text-white';

                if (isAnswered) {
                  if (isSelected && isCorrect) {
                    optionWrapperStyle = 'bg-[#F7FAF0] border-2 border-[#88AA5B] shadow-md text-[#1A2E1A] font-bold';
                    badgeStyle = 'bg-[#88AA5B] text-white';
                  } else if (isSelected && !isCorrect) {
                    optionWrapperStyle = 'bg-rose-50 border-2 border-rose-400 text-rose-950 font-medium';
                    badgeStyle = 'bg-rose-500 text-white';
                  } else if (!isSelected && isTargetCorrect) {
                    optionWrapperStyle = 'bg-[#F7FAF0] border-2 border-[#88AA5B] border-dashed text-[#1A2E1A]';
                    badgeStyle = 'bg-[#88AA5B] text-white';
                  } else {
                    optionWrapperStyle = 'bg-slate-50 border-2 border-slate-200 text-slate-400 opacity-60';
                    badgeStyle = 'bg-slate-200 text-slate-500';
                  }
                }

                return (
                  <button
                    key={opt.key}
                    disabled={isAnswered && isCorrect}
                    onClick={() => handleSelectOption(opt.key)}
                    className={`group flex items-center gap-4 p-4 sm:p-5 rounded-2xl transition-all text-left cursor-pointer ${optionWrapperStyle}`}
                  >
                    <div className={`w-10 h-10 rounded-xl flex items-center justify-center font-bold text-lg shrink-0 transition-colors ${badgeStyle}`}>
                      {isSelected && isCorrect ? <Check className="w-5 h-5 stroke-[3]" /> : isSelected && !isCorrect ? <X className="w-5 h-5 stroke-[3]" /> : opt.key}
                    </div>
                    <span className="text-base sm:text-lg font-medium leading-relaxed">{opt.text}</span>
                  </button>
                );
              })}
            </div>

            {/* Feedback & Action Buttons */}
            {isAnswered && (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="mt-8 border-t border-[#D8E4C0] pt-6 flex flex-col sm:flex-row items-center justify-between gap-4"
              >
                {isCorrect ? (
                  <div className="flex items-center gap-2 text-[#5A6F4A] font-bold text-base w-full sm:w-auto">
                    <CheckCircle2 className="w-5 h-5 text-[#88AA5B] shrink-0" />
                    <span>Chính xác! (+10 điểm)</span>
                  </div>
                ) : (
                  <div className="flex items-center gap-2 text-rose-600 font-bold text-base w-full sm:w-auto">
                    <span>Chưa chính xác rồi! Em hãy chọn lại nhé.</span>
                  </div>
                )}

                <div className="flex items-center gap-3 w-full sm:w-auto justify-end">
                  {!isCorrect && (
                    <button
                      onClick={handleRetryCurrent}
                      className="px-5 py-3 rounded-full border-2 border-[#D8E4C0] hover:bg-[#E8F1D4] text-[#5A6F4A] font-bold text-sm cursor-pointer"
                    >
                      Thử lại câu này 🔄
                    </button>
                  )}

                  {isCorrect && (
                    <button
                      onClick={handleNext}
                      className="w-full sm:w-auto bg-[#F27D26] text-white px-8 py-3.5 rounded-full font-bold text-base shadow-lg hover:brightness-110 active:scale-95 flex items-center justify-center gap-2 cursor-pointer uppercase tracking-wide"
                    >
                      <span>{currentIndex < ROUND1_QUESTIONS.length - 1 ? 'TIẾP THEO ➔' : 'TỔNG KẾT VÒNG 1 🏆'}</span>
                    </button>
                  )}
                </div>
              </motion.div>
            )}
          </motion.div>
        </AnimatePresence>
      ) : (
        /* Round 1 Victory Summary Card */
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="bg-white rounded-[32px] p-6 sm:p-10 border-4 border-[#88AA5B] shadow-2xl text-center relative overflow-hidden space-y-6"
        >
          <div className="w-20 h-20 bg-[#E8F1D4] text-[#88AA5B] rounded-3xl flex items-center justify-center mx-auto border-2 border-[#D8E4C0] shadow-md">
            <Award className="w-10 h-10" />
          </div>

          <div>
            <span className="text-xs font-bold uppercase tracking-widest text-[#5A6F4A] bg-[#E8F1D4] px-4 py-1.5 rounded-full border border-[#D8E4C0]">
              Hoàn thành Vòng 1
            </span>

            <h2 className="text-2xl sm:text-4xl font-serif font-bold text-[#1A2E1A] mt-3">
              Đền Thờ Tri Thức Đã Mở Cửa!
            </h2>

            <p className="text-[#4A5D3F] mt-2 text-base max-w-md mx-auto leading-relaxed">
              Em đã trả lời đúng các câu hỏi về 4 nhóm chất dinh dưỡng chính và xuất sắc hoàn thành thử thách đầu tiên!
            </p>
          </div>

          <div className="p-5 bg-[#F7FAF0] rounded-2xl border-2 border-[#D8E4C0] inline-block text-center min-w-[260px]">
            <p className="text-xs text-[#5A6F4A] font-bold uppercase tracking-wider">Điểm Vòng 1 của em</p>
            <p className="text-4xl font-bold text-[#88AA5B] mt-1">{roundScore} / 40 điểm</p>
            <div className="mt-2 text-xs font-bold text-amber-900 bg-amber-100 px-3 py-1 rounded-full inline-flex items-center gap-1 border border-amber-300">
              🏆 Huy Hiệu: Bằng Sáng Lập Tri Thức
            </div>
          </div>

          <div>
            <button
              onClick={() => onComplete(roundScore)}
              className="w-full sm:w-auto px-10 py-4 rounded-full bg-[#F27D26] text-white font-bold text-lg shadow-xl hover:brightness-110 active:scale-95 transition-all flex items-center justify-center gap-3 mx-auto cursor-pointer uppercase tracking-wide"
            >
              <span>VÒNG 2: KHU RỪNG PHÂN LOẠI ➔</span>
            </button>
          </div>
        </motion.div>
      )}
    </div>
  );
};
