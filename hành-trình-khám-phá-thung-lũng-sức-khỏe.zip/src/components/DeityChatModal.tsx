import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ChatMessage, StudentProfile } from '../types';
import { X, Send, Sparkles, MessageSquareHeart, Bot } from 'lucide-react';
import { soundFx } from '../utils/audio';

interface DeityChatModalProps {
  isOpen: boolean;
  onClose: () => void;
  student: StudentProfile;
}

const SAMPLE_QUESTIONS = [
  'Thần Dinh Dưỡng ơi, tại sao em phải ăn nhiều rau xanh?',
  'Ăn trái cây thay cơm có đủ chất không ạ?',
  'Thực phẩm nào giúp em cao lớn nhất?',
  'Tại sao ăn nhiều đồ ngọt lại bị đau răng và béo phì?',
];

export const DeityChatModal: React.FC<DeityChatModalProps> = ({ isOpen, onClose, student }) => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: '1',
      sender: 'deity',
      text: `Thần Dinh Dưỡng chào ${student.name || 'em'}! Em có thắc mắc gì về thức ăn, sức khỏe hay các món ăn hằng ngày không? Hãy hỏi Thần nhé! 🍎🥦`,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    },
  ]);

  const [inputQuestion, setInputQuestion] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleSend = async (questionText?: string) => {
    const q = questionText || inputQuestion;
    if (!q.trim() || isLoading) return;

    soundFx.playClick();
    const userMsg: ChatMessage = {
      id: Date.now().toString(),
      sender: 'user',
      text: q.trim(),
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg]);
    if (!questionText) setInputQuestion('');
    setIsLoading(true);

    try {
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          question: q.trim(),
          studentName: student.name,
        }),
      });

      const data = await response.json();
      const deityReply = data.reply || 'Thần Dinh Dưỡng khuyên em hãy ăn thật đa dạng các món ăn nhé!';

      const deityMsg: ChatMessage = {
        id: (Date.now() + 1).toString(),
        sender: 'deity',
        text: deityReply,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };

      setMessages((prev) => [...prev, deityMsg]);
      soundFx.speak(deityReply);
    } catch (err) {
      console.error('Chat error:', err);
      const deityMsg: ChatMessage = {
        id: (Date.now() + 1).toString(),
        sender: 'deity',
        text: `Chào ${student.name}! Ăn uống đủ 4 nhóm chất chính là chìa khóa vàng giúp em thông minh và khỏe mạnh mỗi ngày đấy! ✨`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      setMessages((prev) => [...prev, deityMsg]);
    } finally {
      setIsLoading(false);
    }
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/60 backdrop-blur-xs">
        <motion.div
          initial={{ opacity: 0, scale: 0.9, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.9, y: 20 }}
          className="bg-white rounded-3xl w-full max-w-lg shadow-2xl border-4 border-emerald-300 overflow-hidden flex flex-col h-[520px] max-h-[90vh]"
        >
          {/* Modal Header */}
          <div className="bg-gradient-to-r from-emerald-500 via-teal-500 to-amber-500 p-4 text-white flex items-center justify-between shrink-0">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-2xl bg-white/20 backdrop-blur-xs flex items-center justify-center text-xl">
                ✨
              </div>
              <div>
                <h3 className="font-extrabold text-base leading-tight">Hỏi Đáp Cùng Thần Dinh Dưỡng</h3>
                <p className="text-[11px] text-emerald-100 font-medium">Trò chuyện học tập trực tuyến</p>
              </div>
            </div>

            <button
              onClick={() => {
                soundFx.playClick();
                onClose();
              }}
              className="w-8 h-8 rounded-full bg-white/20 hover:bg-white/30 flex items-center justify-center transition-colors cursor-pointer"
            >
              <X className="w-4 h-4 text-white" />
            </button>
          </div>

          {/* Sample Questions Chips */}
          <div className="bg-emerald-50/80 p-2.5 border-b border-emerald-100 shrink-0 overflow-x-auto flex items-center gap-2 scrollbar-none">
            <span className="text-[10px] font-extrabold uppercase tracking-wider text-emerald-800 shrink-0">
              Gợi ý câu hỏi:
            </span>
            {SAMPLE_QUESTIONS.map((sq, i) => (
              <button
                key={i}
                onClick={() => handleSend(sq)}
                className="text-xs bg-white hover:bg-emerald-100 border border-emerald-200 text-emerald-900 px-2.5 py-1 rounded-full whitespace-nowrap shrink-0 transition-colors cursor-pointer font-medium"
              >
                {sq}
              </button>
            ))}
          </div>

          {/* Messages Area */}
          <div className="flex-1 overflow-y-auto p-4 space-y-3 bg-slate-50/50">
            {messages.map((msg) => (
              <div
                key={msg.id}
                className={`flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                <div
                  className={`max-w-[85%] rounded-2xl p-3 text-xs sm:text-sm font-medium leading-relaxed shadow-xs ${
                    msg.sender === 'user'
                      ? 'bg-emerald-600 text-white rounded-br-none'
                      : 'bg-white border border-emerald-200 text-slate-800 rounded-bl-none'
                  }`}
                >
                  <p>{msg.text}</p>
                  <span className={`block text-[10px] mt-1 ${msg.sender === 'user' ? 'text-emerald-200' : 'text-slate-400'}`}>
                    {msg.timestamp}
                  </span>
                </div>
              </div>
            ))}
            {isLoading && (
              <div className="flex justify-start">
                <div className="bg-white border border-emerald-200 rounded-2xl p-3 text-xs text-slate-500 font-bold flex items-center gap-2 animate-pulse">
                  <Bot className="w-4 h-4 text-emerald-600" />
                  <span>Thần Dinh Dưỡng đang trả lời...</span>
                </div>
              </div>
            )}
          </div>

          {/* Input Area */}
          <div className="p-3 bg-white border-t border-slate-200 shrink-0 flex items-center gap-2">
            <input
              type="text"
              value={inputQuestion}
              onChange={(e) => setInputQuestion(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSend()}
              placeholder="Nhập câu hỏi của em ở đây..."
              className="flex-1 px-3.5 py-2.5 rounded-xl border border-slate-300 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-200 outline-none text-xs sm:text-sm font-medium"
            />
            <button
              onClick={() => handleSend()}
              disabled={isLoading || !inputQuestion.trim()}
              className="px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-bold text-xs sm:text-sm flex items-center gap-1.5 transition-colors cursor-pointer disabled:opacity-50"
            >
              <span>Gửi</span>
              <Send className="w-3.5 h-3.5" />
            </button>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
