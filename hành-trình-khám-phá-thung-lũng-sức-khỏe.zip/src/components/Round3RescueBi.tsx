import React, { useState } from 'react';
import { motion } from 'motion/react';
import { BI_CONSEQUENCES_OPTIONS, ADVICE_SUGGESTION_CHIPS } from '../data/gameData';
import { StudentProfile } from '../types';
import { NutritionDeityAvatar } from './NutritionDeityAvatar';
import { HeartHandshake, AlertTriangle, Send, Sparkles, Award, ArrowRight, CheckSquare, Square } from 'lucide-react';
import { soundFx } from '../utils/audio';

interface Round3RescueBiProps {
  student: StudentProfile;
  onComplete: (score: number) => void;
  audioEnabled: boolean;
  onToggleAudio: () => void;
  onOpenChat: () => void;
}

export const Round3RescueBi: React.FC<Round3RescueBiProps> = ({
  student,
  onComplete,
  audioEnabled,
  onToggleAudio,
  onOpenChat,
}) => {
  // Step 1: Is meal balanced?
  const [isBalancedAnswer, setIsBalancedAnswer] = useState<boolean | null>(null);
  const [step1Checked, setStep1Checked] = useState(false);

  // Step 2: Selected consequences
  const [selectedConsequences, setSelectedConsequences] = useState<string[]>([]);
  const [step2Checked, setStep2Checked] = useState(false);

  // Step 3: Advice text
  const [adviceText, setAdviceText] = useState('');
  const [isEvaluating, setIsEvaluating] = useState(false);
  const [evaluationResult, setEvaluationResult] = useState<{
    praise: string;
    summary: string;
    badgeName: string;
  } | null>(null);

  const [roundScore, setRoundScore] = useState(0);

  // Step 1 handler
  const handleAnswerStep1 = (answer: boolean) => {
    soundFx.playClick();
    setIsBalancedAnswer(answer);
    setStep1Checked(true);
    if (!answer) {
      soundFx.playCorrect();
      setRoundScore((prev) => prev + 10);
    } else {
      soundFx.playWrong();
    }
  };

  // Step 2 toggle
  const toggleConsequence = (id: string) => {
    soundFx.playClick();
    setSelectedConsequences((prev) =>
      prev.includes(id) ? prev.filter((i) => i !== id) : [...prev, id]
    );
  };

  const handleConfirmStep2 = () => {
    if (selectedConsequences.length === 0) {
      soundFx.playWrong();
      return;
    }
    soundFx.playCorrect();
    setStep2Checked(true);
    // Check if correct options selected
    const correctCount = selectedConsequences.filter((id) =>
      BI_CONSEQUENCES_OPTIONS.find((opt) => opt.id === id)?.isCorrect
    ).length;
    setRoundScore((prev) => prev + correctCount * 5);
  };

  // Step 3 evaluation via backend API
  const handleSubmitAdvice = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!adviceText.trim()) return;

    soundFx.playClick();
    setIsEvaluating(true);

    try {
      const response = await fetch('/api/evaluate-bi', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          studentName: student.name,
          studentClass: student.className,
          adviceText,
          checkedReasons: selectedConsequences,
        }),
      });

      const data = await response.json();
      setEvaluationResult(data);
      soundFx.playFanfare();
      setRoundScore((prev) => prev + 15);
    } catch (err) {
      console.error('Error evaluating advice:', err);
      setEvaluationResult({
        praise: `Thần Dinh Dưỡng vô cùng tự hào về lời khuyên đầy quan tâm của ${student.name} dành cho bạn Bi!`,
        summary: 'Bi đã hiểu bài học và hứa sẽ tập ăn rau xà lách, xoài và măng cụt hằng ngày để đủ 4 nhóm chất!',
        badgeName: 'Anh Hùng Dinh Dưỡng Thấu Cảm 🏆',
      });
      soundFx.playFanfare();
      setRoundScore((prev) => prev + 15);
    } finally {
      setIsEvaluating(false);
    }
  };

  return (
    <div className="max-w-3xl mx-auto p-4 sm:p-6 space-y-6">
      {/* Deity Avatar */}
      <NutritionDeityAvatar
        message={
          evaluationResult
            ? evaluationResult.praise
            : !step1Checked
            ? 'Vòng 3: Giải Cứu Bạn Bi! Hãy giúp Thần phân tích bữa ăn của Bi xem có cân bằng không nhé!'
            : !step2Checked
            ? 'Chính xác! Bữa ăn của Bi chưa hề cân bằng. Nếu duy trì thói quen này, Bi sẽ gặp hậu quả gì?'
            : 'Em hãy viết một lời khuyên ngắn gửi đến bạn Bi để giúp Bi khỏe mạnh và cao lớn nhé!'
        }
        mood={evaluationResult ? 'celebrate' : 'encouraging'}
        audioEnabled={audioEnabled}
        onToggleAudio={onToggleAudio}
        onAskClick={onOpenChat}
      />

      {/* Scenario Banner Card */}
      <div className="bg-[#E8F1D4] border-2 border-[#D8E4C0] rounded-[28px] p-5 sm:p-6 shadow-xs flex flex-col sm:flex-row items-center gap-4">
        <div className="w-16 h-16 rounded-2xl bg-[#88AA5B] text-white flex items-center justify-center text-3xl font-bold shrink-0 shadow-xs border-2 border-[#D8E4C0]">
          👦🏻
        </div>
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-xs font-bold uppercase tracking-wider bg-white text-[#5A6F4A] px-3 py-0.5 rounded-full border border-[#D8E4C0]">
              Tình Huống
            </span>
            <h3 className="font-serif font-bold text-[#1A2E1A] text-base sm:text-lg">Tập Quán Ăn Uống Của Bạn Bi</h3>
          </div>
          <p className="text-sm sm:text-base font-medium text-[#2D402A] leading-relaxed">
            "Bạn Bi chỉ thích ăn <span className="text-amber-900 bg-amber-100 px-2 py-0.5 rounded-lg font-bold">thịt heo</span> và <span className="text-amber-900 bg-amber-100 px-2 py-0.5 rounded-lg font-bold">cơm</span>, tuyệt đối không ăn xoài, măng cụt hay rau xà lách."
          </p>
        </div>
      </div>

      {/* Step 3.1: Is Bi's meal balanced? */}
      {!step1Checked && (
        <motion.div
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white/90 backdrop-blur-sm rounded-[32px] p-6 sm:p-8 border-2 border-[#D8E4C0] shadow-sm space-y-5"
        >
          <h3 className="font-serif font-bold text-xl text-[#1A2E1A] flex items-center gap-3">
            <span className="w-8 h-8 rounded-full bg-[#88AA5B] text-white text-sm flex items-center justify-center font-bold">1</span>
            Bữa ăn của Bi đã cân bằng dinh dưỡng chưa?
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
            <button
              onClick={() => handleAnswerStep1(true)}
              className="p-5 rounded-2xl border-2 border-[#D8E4C0] hover:border-rose-400 hover:bg-rose-50 text-[#2D402A] font-medium text-sm sm:text-base text-left transition-all cursor-pointer"
            >
              A. Đã rất cân bằng rồi, cơm và thịt heo đủ giúp Bi cao lớn.
            </button>

            <button
              onClick={() => handleAnswerStep1(false)}
              className="p-5 rounded-2xl border-2 border-[#88AA5B] bg-[#F7FAF0] hover:bg-[#E8F1D4] text-[#1A2E1A] font-bold text-sm sm:text-base text-left transition-all cursor-pointer shadow-xs"
            >
              B. Chưa cân bằng! Bi mới chỉ ăn Bột Đường & Đạm, thiếu Vitamin, Khoáng chất & Chất xơ từ rau quả! 🥦🥭
            </button>
          </div>
        </motion.div>
      )}

      {/* Step 3.2: Consequences of Bi's habit */}
      {step1Checked && !step2Checked && (
        <motion.div
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white/90 backdrop-blur-sm rounded-[32px] p-6 sm:p-8 border-2 border-[#D8E4C0] shadow-sm space-y-5"
        >
          <div className="flex items-center justify-between border-b border-[#D8E4C0] pb-4">
            <h3 className="font-serif font-bold text-xl text-[#1A2E1A] flex items-center gap-3">
              <span className="w-8 h-8 rounded-full bg-[#88AA5B] text-white text-sm flex items-center justify-center font-bold">2</span>
              Nếu duy trì thói quen này, Bi sẽ bị làm sao? (Chọn các ý đúng)
            </h3>
          </div>

          <div className="space-y-3 pt-1">
            {BI_CONSEQUENCES_OPTIONS.map((opt) => {
              const isChecked = selectedConsequences.includes(opt.id);
              return (
                <button
                  key={opt.id}
                  type="button"
                  onClick={() => toggleConsequence(opt.id)}
                  className={`w-full text-left p-4 rounded-2xl border-2 font-medium text-sm sm:text-base flex items-center gap-3 transition-all cursor-pointer ${
                    isChecked
                      ? 'bg-[#F7FAF0] text-[#1A2E1A] border-[#88AA5B] shadow-xs font-bold'
                      : 'bg-white hover:bg-[#F7FAF0] text-[#2D402A] border-[#D8E4C0]'
                  }`}
                >
                  {isChecked ? (
                    <CheckSquare className="w-5 h-5 text-[#88AA5B] shrink-0" />
                  ) : (
                    <Square className="w-5 h-5 text-[#5A6F4A] shrink-0" />
                  )}
                  <span>{opt.label}</span>
                </button>
              );
            })}
          </div>

          <button
            onClick={handleConfirmStep2}
            className="w-full py-4 rounded-full bg-[#F27D26] text-white font-bold text-base shadow-lg hover:brightness-110 active:scale-95 transition-all flex items-center justify-center gap-2 cursor-pointer mt-4 uppercase tracking-wide"
          >
            <span>XÁC NHẬN NHẬN XÉT ➔</span>
          </button>
        </motion.div>
      )}

      {/* Step 3.3: Compose Advice to Bi */}
      {step1Checked && step2Checked && !evaluationResult && (
        <motion.div
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white/90 backdrop-blur-sm rounded-[32px] p-6 sm:p-8 border-2 border-[#D8E4C0] shadow-sm space-y-5"
        >
          <h3 className="font-serif font-bold text-xl text-[#1A2E1A] flex items-center gap-3">
            <span className="w-8 h-8 rounded-full bg-[#88AA5B] text-white text-sm flex items-center justify-center font-bold">3</span>
            Lời khuyên chân thành của em dành cho bạn Bi
          </h3>

          {/* Quick Suggestion Chips */}
          <div>
            <p className="text-xs font-bold text-[#5A6F4A] uppercase tracking-wider mb-2">Gợi ý lời khuyên mẫu (Chạm để chèn nhanh):</p>
            <div className="space-y-2">
              {ADVICE_SUGGESTION_CHIPS.map((chip, idx) => (
                <button
                  key={idx}
                  type="button"
                  onClick={() => {
                    soundFx.playClick();
                    setAdviceText(chip);
                  }}
                  className="w-full text-left p-3 rounded-xl bg-[#F7FAF0] hover:bg-[#E8F1D4] border border-[#D8E4C0] text-xs text-[#1A2E1A] font-medium transition-colors cursor-pointer"
                >
                  💡 "{chip}"
                </button>
              ))}
            </div>
          </div>

          <form onSubmit={handleSubmitAdvice} className="space-y-4 pt-2">
            <div>
              <textarea
                value={adviceText}
                onChange={(e) => setAdviceText(e.target.value)}
                placeholder="Nhập lời khuyên thân thiện của em gửi bạn Bi ở đây..."
                rows={3}
                className="w-full p-4 rounded-2xl border-2 border-[#D8E4C0] focus:border-[#88AA5B] focus:bg-[#F7FAF0] outline-none text-[#1A2E1A] text-sm sm:text-base font-medium bg-white"
              />
            </div>

            <button
              type="submit"
              disabled={isEvaluating || !adviceText.trim()}
              className="w-full py-4 rounded-full bg-[#F27D26] text-white font-bold text-base shadow-lg hover:brightness-110 active:scale-95 transition-all flex items-center justify-center gap-3 cursor-pointer disabled:opacity-50 uppercase tracking-wide"
            >
              {isEvaluating ? (
                <span>THẦN DINH DƯỠNG ĐANG LẮNG NGHE... ⏳</span>
              ) : (
                <>
                  <span>GỬI LỜI KHUYÊN GIẢI CỨU BẠN BI</span>
                  <Send className="w-5 h-5" />
                </>
              )}
            </button>
          </form>
        </motion.div>
      )}

      {/* Evaluation & Result Card */}
      {evaluationResult && (
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="bg-white rounded-[32px] p-6 sm:p-10 border-4 border-[#88AA5B] shadow-2xl text-center space-y-6 relative overflow-hidden"
        >
          <div className="w-20 h-20 bg-[#E8F1D4] text-[#88AA5B] rounded-3xl flex items-center justify-center mx-auto border-2 border-[#D8E4C0] shadow-md">
            <Award className="w-10 h-10" />
          </div>

          <div>
            <span className="text-xs font-bold uppercase tracking-widest text-[#5A6F4A] bg-[#E8F1D4] px-4 py-1.5 rounded-full border border-[#D8E4C0]">
              {evaluationResult.badgeName || 'Anh Hùng Dinh Dưỡng 🏆'}
            </span>
            <h2 className="text-2xl sm:text-4xl font-serif font-bold text-[#1A2E1A] mt-3">
              Bi Đã Được Giải Cứu Rồi!
            </h2>
          </div>

          <div className="bg-[#F7FAF0] p-6 rounded-2xl border-2 border-[#D8E4C0] text-left space-y-2">
            <p className="text-xs font-bold text-[#5A6F4A] uppercase tracking-wider">Ghi nhận từ Thần Dinh Dưỡng:</p>
            <p className="text-base sm:text-lg font-serif font-bold text-[#1A2E1A] leading-relaxed">
              "{evaluationResult.summary}"
            </p>
          </div>

          <div className="p-5 bg-[#E8F1D4] rounded-2xl border-2 border-[#D8E4C0] inline-block text-center min-w-[260px]">
            <p className="text-xs text-[#5A6F4A] font-bold uppercase tracking-wider">Điểm Vòng 3 của em</p>
            <p className="text-4xl font-bold text-[#88AA5B] mt-1">{roundScore} / 30 điểm</p>
          </div>

          <div>
            <button
              onClick={() => onComplete(roundScore)}
              className="w-full sm:w-auto px-10 py-4 rounded-full bg-[#F27D26] text-white font-bold text-lg shadow-xl hover:brightness-110 active:scale-95 transition-all flex items-center justify-center gap-3 mx-auto cursor-pointer uppercase tracking-wide"
            >
              <span>NHẬN BẰNG KHEN DANH DỰ 🏆</span>
            </button>
          </div>
        </motion.div>
      )}
    </div>
  );
};
