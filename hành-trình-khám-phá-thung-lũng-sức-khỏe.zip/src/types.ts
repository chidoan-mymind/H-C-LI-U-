export type RoundType = 'welcome' | 'round1' | 'round2' | 'round3' | 'certificate';

export interface StudentProfile {
  name: string;
  className: string;
  avatarSeed: string;
}

export interface Question {
  id: number;
  text: string;
  options: {
    key: 'A' | 'B' | 'C';
    text: string;
  }[];
  correctKey: 'A' | 'B' | 'C';
  explanation: string;
}

export type FoodCategory = 'carbs' | 'protein' | 'fat' | 'vitamin';

export interface FoodItem {
  id: string;
  name: string;
  emoji: string;
  correctCategory: FoodCategory;
  description: string;
}

export interface BasketCategory {
  id: FoodCategory;
  title: string;
  subTitle: string;
  color: string;
  borderColor: string;
  bgColor: string;
  icon: string;
  examples: string;
}

export interface RoundScore {
  round1: number; // Max 40 points
  round2: number; // Max 65 points (5 points per food item)
  round3: number; // Max 30 points
}

export interface Badge {
  id: string;
  title: string;
  description: string;
  icon: string;
  color: string;
}

export interface ChatMessage {
  id: string;
  sender: 'user' | 'deity';
  text: string;
  timestamp: string;
}
