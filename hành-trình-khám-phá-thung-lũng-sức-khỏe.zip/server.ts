import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI } from '@google/genai';

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // Initialize Gemini AI lazily/safely
  const getAi = () => {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      return null;
    }
    return new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });
  };

  // Health check endpoint
  app.get('/api/health', (req, res) => {
    res.json({ status: 'ok', time: new Date().toISOString() });
  });

  // Evaluate Bi advice endpoint
  app.post('/api/evaluate-bi', async (req, res) => {
    try {
      const { studentName, studentClass, adviceText, checkedReasons } = req.body;

      const ai = getAi();
      if (!ai) {
        // Fallback response if API key is not present
        return res.json({
          score: 5,
          praise: `Tuyệt vời lắm ${studentName || 'nhà khám phá'}! Lời khuyên của em rất chính xác và đầy tình thương dành cho bạn Bi.`,
          summary: 'Bi đã hiểu được tầm quan trọng của việc ăn cân bằng 4 nhóm chất và cam kết ăn thêm rau quả!',
          badgeName: 'Anh Hùng Dinh Dưỡng Thấu Cảm 🏆',
        });
      }

      const prompt = `Bạn là "Thần Dinh Dưỡng" - người dẫn đường vui tính, thân thiện, ấm áp dành cho học sinh lớp 4 (10 tuổi).
Học sinh tên là: ${studentName || 'Nhà khám phá nhỏ'} (Lớp: ${studentClass || '4A'}).
Tình huống: Bạn Bi chỉ thích ăn thịt heo và cơm, không ăn xoài, măng cụt hay rau xà lách.

Học sinh đã nhận xét tình huống của Bi với các ý:
- Lựa chọn lý do: ${Array.isArray(checkedReasons) ? checkedReasons.join(', ') : 'Không có'}
- Lời khuyên tự viết gửi bạn Bi: "${adviceText || 'Bi ơi, hãy ăn thêm rau củ quả nhé!'}"

Hãy đánh giá lời khuyên này dưới tư cách Thần Dinh Dưỡng:
1. Tuyên dương sự mẫn cảm và hiểu biết của học sinh.
2. Giải thích nhẹ nhàng vì sao lời khuyên của bạn ấy sẽ giúp Bi khỏe mạnh (có chất xơ, vitamin C, không bị táo bón, da dẻ hồng hào, cao lớn).
3. Cho điểm từ 1 đến 5 sao.

Trả về phản hồi JSON theo cấu trúc:
{
  "praise": "Lời tuyên dương ngọt ngào, hóm hỉnh kèm emoji",
  "summary": "Tóm tắt ngắn gọn lời khuyên dành cho Bi (2 câu)",
  "badgeName": "Tên danh hiệu ngộ nghĩnh"
}`;

      const response = await ai.models.generateContent({
        model: 'gemini-3.6-flash',
        contents: prompt,
        config: {
          responseMimeType: 'application/json',
          systemInstruction: 'Bạn là Thần Dinh Dưỡng siêu vui tính, truyền cảm hứng cho học sinh lớp 4 Việt Nam.',
        },
      });

      const text = response.text || '';
      try {
        const parsed = JSON.parse(text);
        return res.json(parsed);
      } catch {
        return res.json({
          praise: `Thần Dinh Dưỡng rất khen ngợi ${studentName}! Lời khuyên của em vô cùng sâu sắc và chuẩn xác.`,
          summary: 'Bi hứa từ nay sẽ tập ăn rau xà lách, xoài và măng cụt để cơ thể đủ chất và cao lớn!',
          badgeName: 'Anh Hùng Dinh Dưỡng Xuất Sắc 🏆',
        });
      }
    } catch (err) {
      console.error('Error evaluating Bi advice:', err);
      return res.json({
        praise: 'Thần Dinh Dưỡng rất tự hào về lời khuyên đầy quan tâm của em dành cho bạn Bi!',
        summary: 'Bi đã nhận ra bài học và hứa sẽ đổi mới khẩu phần ăn đầy đủ 4 nhóm chất!',
        badgeName: 'Anh Hùng Dinh Dưỡng 🌟',
      });
    }
  });

  // Ask Thần Dinh Dưỡng any question endpoint
  app.post('/api/chat', async (req, res) => {
    try {
      const { question, studentName } = req.body;
      if (!question) {
        return res.status(400).json({ error: 'Missing question' });
      }

      const ai = getAi();
      if (!ai) {
        return res.json({
          reply: `Thần Dinh Dưỡng chào ${studentName || 'bạn nhỏ'}! Ăn uống cân bằng đủ 4 nhóm chất (Bột đường, Đạm, Béo, Vitamin & Khoáng chất) và uống đủ nước chính là bí kíp giúp em luôn khỏe mạnh và thông minh đấy! 🍎🥦🥩✨`,
        });
      }

      const prompt = `Thắc mắc của học sinh lớp 4 (${studentName || 'bạn nhỏ'}): "${question}"
Hãy trả lời ngắn gọn (2-4 câu), ngôn ngữ vui tươi, dễ hiểu, dùng ví dụ sinh động về món ăn gần gũi với học sinh Việt Nam, kèm emoji thích hợp.`;

      const response = await ai.models.generateContent({
        model: 'gemini-3.6-flash',
        contents: prompt,
        config: {
          systemInstruction: 'Bạn là Thần Dinh Dưỡng vui tính, giải thích khoa học thực phẩm cực kỳ dễ hiểu cho trẻ em 10 tuổi.',
        },
      });

      return res.json({ reply: response.text || 'Thần Dinh Dưỡng luôn đồng hành cùng em!' });
    } catch (err) {
      console.error('Error in chat endpoint:', err);
      return res.json({
        reply: 'Thần Dinh Dưỡng khuyên em hãy ăn thật đa dạng các món ăn để nạp đủ chất dinh dưỡng nhé! 🌟',
      });
    }
  });

  // Vite middleware setup
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Thần Dinh Dưỡng Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
