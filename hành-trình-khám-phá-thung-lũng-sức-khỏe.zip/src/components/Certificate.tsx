import React from 'react';
import { motion } from 'motion/react';
import { RoundScore, StudentProfile } from '../types';
import { Award, Printer, RotateCcw, Sparkles, CheckCircle2, Trophy, Star } from 'lucide-react';
import { soundFx } from '../utils/audio';

interface CertificateProps {
  student: StudentProfile;
  scores: RoundScore;
  onRestart: () => void;
}

export const Certificate: React.FC<CertificateProps> = ({ student, scores, onRestart }) => {
  const totalScore = scores.round1 + scores.round2 + scores.round3;
  const maxScore = 135; // 40 + 65 + 30
  const currentDate = new Date().toLocaleDateString('vi-VN', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
  });

  const handlePrint = () => {
    soundFx.playClick();
    window.print();
  };

  return (
    <div className="max-w-4xl mx-auto p-4 sm:p-6 space-y-6">
      {/* Top Banner Controls */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-4 bg-white/90 p-5 rounded-[28px] border-2 border-[#D8E4C0] shadow-sm print:hidden">
        <div>
          <h2 className="font-serif font-bold text-[#1A2E1A] text-xl">
            Chúc Mừng {student.name}! 🎉
          </h2>
          <p className="text-xs text-[#5A6F4A] mt-0.5">
            Em đã chính thức chinh phục Thung Lũng Sức Khỏe và nhận bằng chứng nhận danh dự!
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={handlePrint}
            className="px-6 py-3 rounded-full bg-[#88AA5B] hover:bg-[#5A6F4A] text-white font-bold text-sm flex items-center gap-2 cursor-pointer shadow-sm uppercase tracking-wide"
          >
            <Printer className="w-4 h-4" />
            <span>IN / TẢI BẰNG KHEN</span>
          </button>

          <button
            onClick={onRestart}
            className="px-5 py-3 rounded-full border-2 border-[#D8E4C0] hover:bg-[#E8F1D4] text-[#5A6F4A] font-bold text-sm flex items-center gap-2 cursor-pointer uppercase tracking-wide"
          >
            <RotateCcw className="w-4 h-4" />
            <span>CHƠI LẠI</span>
          </button>
        </div>
      </div>

      {/* Printable Certificate Frame */}
      <motion.div
        initial={{ opacity: 0, scale: 0.98 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.5 }}
        className="bg-[#F7FAF0] rounded-[36px] p-6 sm:p-12 border-8 border-double border-[#88AA5B] shadow-2xl relative overflow-hidden text-center font-serif text-[#1A2E1A] print:border-4 print:p-8 print:shadow-none print:bg-white"
      >
        {/* Decorative Corners */}
        <div className="absolute top-4 left-4 w-10 h-10 border-t-4 border-l-4 border-[#88AA5B] rounded-tl-xl" />
        <div className="absolute top-4 right-4 w-10 h-10 border-t-4 border-r-4 border-[#88AA5B] rounded-tr-xl" />
        <div className="absolute bottom-4 left-4 w-10 h-10 border-b-4 border-l-4 border-[#88AA5B] rounded-bl-xl" />
        <div className="absolute bottom-4 right-4 w-10 h-10 border-b-4 border-r-4 border-[#88AA5B] rounded-br-xl" />

        {/* Certificate Emblem */}
        <div className="inline-flex items-center justify-center w-20 h-20 bg-[#88AA5B] rounded-full shadow-lg border-4 border-[#D8E4C0] mb-4 text-white">
          <Trophy className="w-10 h-10" />
        </div>

        <p className="text-xs sm:text-sm font-sans font-bold uppercase tracking-widest text-[#5A6F4A] bg-[#E8F1D4] px-4 py-1.5 rounded-full w-fit mx-auto border border-[#D8E4C0]">
          Thung Lũng Sức Khỏe - Dinh Dưỡng Lớp 4
        </p>

        <h1 className="text-2xl sm:text-4xl font-serif font-bold text-[#1A2E1A] tracking-tight mt-4 uppercase">
          BẰNG CÔNG NHẬN
        </h1>
        <p className="text-lg sm:text-2xl font-serif font-bold text-[#88AA5B] italic">
          ANH HÙNG DINH DƯỠNG
        </p>

        <div className="my-6">
          <p className="text-sm text-[#5A6F4A] font-sans italic">Trao tặng cho học sinh:</p>
          <h2 className="text-3xl sm:text-5xl font-serif font-bold text-[#1A2E1A] my-2 underline decoration-[#F27D26] decoration-wavy underline-offset-8">
            {student.name}
          </h2>
          <p className="text-base font-bold text-[#5A6F4A] font-sans mt-3">
            Lớp: <span className="bg-[#E8F1D4] text-[#1A2E1A] px-4 py-1 rounded-full border border-[#D8E4C0] font-bold">{student.className}</span>
          </p>
        </div>

        <p className="text-sm sm:text-base text-[#4A5D3F] max-w-xl mx-auto leading-relaxed font-sans mb-6">
          Đã xuất sắc hoàn thành tất cả 3 Vòng Thử Thách trong <br className="hidden sm:block" />
          <strong className="text-[#1A2E1A]">"Hành Trình Khám Phá Thung Lũng Sức Khỏe"</strong>, <br />
          nắm vững kiến thức 4 nhóm chất dinh dưỡng và đưa ra lời khuyên ăn uống cân bằng tuyệt vời!
        </p>

        {/* Score Breakdown Table */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 my-6 max-w-2xl mx-auto font-sans">
          <div className="bg-white p-3.5 rounded-2xl border-2 border-[#D8E4C0] shadow-xs">
            <p className="text-[11px] text-[#5A6F4A] font-bold uppercase tracking-wider">V1: Đền Thờ Tri Thức</p>
            <p className="text-2xl font-bold text-[#88AA5B] mt-1">{scores.round1} / 40 điểm</p>
          </div>
          <div className="bg-white p-3.5 rounded-2xl border-2 border-[#D8E4C0] shadow-xs">
            <p className="text-[11px] text-[#5A6F4A] font-bold uppercase tracking-wider">V2: Khu Rừng Phân Loại</p>
            <p className="text-2xl font-bold text-[#88AA5B] mt-1">{scores.round2} / 65 điểm</p>
          </div>
          <div className="bg-white p-3.5 rounded-2xl border-2 border-[#D8E4C0] shadow-xs">
            <p className="text-[11px] text-[#5A6F4A] font-bold uppercase tracking-wider">V3: Giải Cứu Bạn Bi</p>
            <p className="text-2xl font-bold text-[#88AA5B] mt-1">{scores.round3} / 30 điểm</p>
          </div>
        </div>

        {/* Total Badge */}
        <div className="inline-flex items-center gap-2 bg-[#F27D26] text-white font-bold text-lg sm:text-xl px-8 py-3 rounded-full shadow-lg border-2 border-amber-300 font-sans my-3 uppercase tracking-wide">
          <Star className="w-6 h-6 fill-white text-white" />
          <span>TỔNG ĐIỂM: {totalScore} / {maxScore} ĐIỂM</span>
        </div>

        {/* Signatures & Seal */}
        <div className="grid grid-cols-2 gap-4 mt-8 pt-6 border-t-2 border-[#D8E4C0] font-sans text-xs sm:text-sm">
          <div>
            <p className="text-[#5A6F4A] font-bold uppercase tracking-wider">Ngày cấp chứng nhận</p>
            <p className="font-bold text-[#1A2E1A] text-base mt-1">{currentDate}</p>
          </div>
          <div>
            <p className="text-[#5A6F4A] font-bold uppercase tracking-wider">Thần Dinh Dưỡng</p>
            <p className="italic text-[#88AA5B] font-serif text-lg sm:text-xl mt-1 font-bold">
              ✨ Thần Dinh Dưỡng ✨
            </p>
          </div>
        </div>
      </motion.div>
    </div>
  );
};
