import { BasketCategory, FoodItem, Question } from '../types';

export const ROUND1_QUESTIONS: Question[] = [
  {
    id: 1,
    text: 'Thực phẩm được chia thành mấy nhóm chất dinh dưỡng chính?',
    options: [
      { key: 'A', text: '2 nhóm (động vật và thực vật)' },
      { key: 'B', text: '3 nhóm (đạm, béo, vitamin)' },
      { key: 'C', text: '4 nhóm (bột đường, chất đạm, chất béo, vitamin và khoáng chất)' },
    ],
    correctKey: 'C',
    explanation: 'Chính xác! Thực phẩm được chia thành 4 nhóm chất dinh dưỡng chính: Chất bột đường, chất đạm, chất béo, vitamin và khoáng chất. Mỗi nhóm đều rất quan trọng!',
  },
  {
    id: 2,
    text: 'Nhóm thức ăn nào có vai trò chính là xây dựng và phát triển cơ thể giúp em cao lớn hơn?',
    options: [
      { key: 'A', text: 'Nhóm chứa nhiều chất đạm.' },
      { key: 'B', text: 'Nhóm chứa nhiều chất bột đường.' },
      { key: 'C', text: 'Nhóm chứa nhiều vitamin và khoáng chất.' },
    ],
    correctKey: 'A',
    explanation: 'Giỏi lắm! Chất đạm (có trong thịt, cá, trứng, sữa, đậu...) chính là những "viên gạch" kỳ diệu giúp xây dựng cơ bắp, phát triển chiều cao và trí não!',
  },
  {
    id: 3,
    text: 'Tại sao chúng ta cần phải ăn phối hợp nhiều loại thức ăn và thường xuyên thay đổi món?',
    options: [
      { key: 'A', text: 'Để thức ăn có màu sắc đẹp mắt hơn.' },
      { key: 'B', text: 'Vì không có một loại thức ăn nào cung cấp đủ các chất dinh dưỡng cho nhu cầu của cơ thể.' },
      { key: 'C', text: 'Để giúp chúng ta không bị khát nước.' },
    ],
    correctKey: 'B',
    explanation: 'Đúng rồi! Không có một món ăn đơn lẻ nào chứa tất cả dinh dưỡng. Phối hợp nhiều món ăn mới tạo nên bữa ăn cân bằng hoàn hảo!',
  },
  {
    id: 4,
    text: 'Nhóm thực phẩm nào cung cấp nhiều vitamin và chất xơ nhất, giúp hệ tiêu hóa luôn khỏe mạnh?',
    options: [
      { key: 'A', text: 'Thịt heo, cá.' },
      { key: 'B', text: 'Rau xà lách, xoài, măng cụt.' },
      { key: 'C', text: 'Bánh mì, phô mai.' },
    ],
    correctKey: 'B',
    explanation: 'Tuyệt vời! Rau củ và trái cây tươi như rau xà lách, xoài, măng cụt chứa lượng chất xơ và vitamin dồi dào, giúp hệ tiêu hóa nhẹ nhàng, mịn màng da dẻ!',
  },
];

export const BASKETS: BasketCategory[] = [
  {
    id: 'carbs',
    title: 'Nhóm Chất Bột Đường',
    subTitle: 'Cung cấp năng lượng chính cho hoạt động',
    color: 'from-amber-500 to-yellow-600',
    borderColor: 'border-amber-400',
    bgColor: 'bg-amber-500/10',
    icon: '🍞',
    examples: 'VD: Bánh mì, cơm, khoai...',
  },
  {
    id: 'protein',
    title: 'Nhóm Chất Đạm',
    subTitle: 'Xây dựng cơ thể, giúp cao lớn',
    color: 'from-rose-500 to-red-600',
    borderColor: 'border-rose-400',
    bgColor: 'bg-rose-500/10',
    icon: '🥩',
    examples: 'VD: Thịt heo, cá, tôm, trứng, sữa, đậu...',
  },
  {
    id: 'fat',
    title: 'Nhóm Chất Béo',
    subTitle: 'Dự trữ năng lượng & hòa tan vitamin',
    color: 'from-yellow-400 to-amber-500',
    borderColor: 'border-yellow-400',
    bgColor: 'bg-yellow-500/10',
    icon: '🥑',
    examples: 'VD: Quả bơ, phô mai, dầu ăn...',
  },
  {
    id: 'vitamin',
    title: 'Nhóm Vitamin & Khoáng Chất',
    subTitle: 'Tăng sức đề kháng & tốt cho tiêu hóa',
    color: 'from-emerald-500 to-green-600',
    borderColor: 'border-emerald-400',
    bgColor: 'bg-emerald-500/10',
    icon: '🥦',
    examples: 'VD: Măng cụt, xoài, rau xà lách...',
  },
];

export const FOOD_ITEMS: FoodItem[] = [
  { id: 'thit_heo', name: 'Thịt heo', emoji: '🥩', correctCategory: 'protein', description: 'Giàu chất đạm giúp cơ bắp săn chắc' },
  { id: 'mang_cut', name: 'Măng cụt', emoji: '🥭', correctCategory: 'vitamin', description: 'Nhiều vitamin C & chất chống oxy hóa' },
  { id: 'sua', name: 'Sữa', emoji: '🥛', correctCategory: 'protein', description: 'Cung cấp chất đạm & canxi phát triển xương' },
  { id: 'banh_mi', name: 'Bánh mì', emoji: '🍞', correctCategory: 'carbs', description: 'Chứa chất bột đường nạp năng lượng hằng ngày' },
  { id: 'ca', name: 'Cá', emoji: '🐟', correctCategory: 'protein', description: 'Chất đạm dễ tiêu hóa & Omega-3 bổ mắt' },
  { id: 'xoai', name: 'Xoài', emoji: '🥭', correctCategory: 'vitamin', description: 'Giàu vitamin A & vitamin C tươi mát' },
  { id: 'pho_mai', name: 'Phô mai', emoji: '🧀', correctCategory: 'fat', description: 'Nhiều chất béo & canxi dồi dào' },
  { id: 'rau_xa_lach', name: 'Rau xà lách', emoji: '🥬', correctCategory: 'vitamin', description: 'Chứa cực kỳ nhiều chất xơ giúp tiêu hóa tốt' },
  { id: 'dau', name: 'Đậu', emoji: '🫘', correctCategory: 'protein', description: 'Chất đạm thực vật vô cùng lành tính' },
  { id: 'trung', name: 'Trứng', emoji: '🥚', correctCategory: 'protein', description: 'Giàu đạm & dưỡng chất cho trí não' },
  { id: 'tom', name: 'Tôm', emoji: '🦐', correctCategory: 'protein', description: 'Đạm động vật biển thơm ngon & nhiều canxi' },
  { id: 'thit_bo', name: 'Thịt bò', emoji: '🥩', correctCategory: 'protein', description: 'Cung cấp nhiều sắt & đạm chất lượng cao' },
  { id: 'qua_bo', name: 'Quả bơ', emoji: '🥑', correctCategory: 'fat', description: 'Chứa chất béo tự nhiên tốt cho tim mạch' },
];

export const BI_CONSEQUENCES_OPTIONS = [
  { id: 'lack_vitamins', label: 'Thiếu vitamin và khoáng chất cần thiết', isCorrect: true },
  { id: 'constipation', label: 'Dễ bị táo bón do thiếu chất xơ từ rau quả', isCorrect: true },
  { id: 'unbalanced_growth', label: 'Cơ thể kém phát triển cân đối và hay mệt mỏi', isCorrect: true },
  { id: 'all_good', label: 'Cơ thể vẫn phát triển hoàn toàn bình thường', isCorrect: false },
];

export const ADVICE_SUGGESTION_CHIPS = [
  'Bi ơi, thịt heo và cơm rất ngon nhưng ăn thêm rau xà lách và xoài để không bị táo bón nhé!',
  'Bi nên phối hợp cả 4 nhóm chất để cơ thể vừa cao lớn vừa có làn da hồng hào, đề kháng tốt!',
  'Bi ơi, thử tập ăn từng miếng rau nhỏ và một múi măng cụt ngọt lịm mỗi bữa ăn xem sao!',
];
